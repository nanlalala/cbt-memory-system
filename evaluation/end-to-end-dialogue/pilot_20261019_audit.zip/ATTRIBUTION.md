# LoCoMo pilot audit material

This artifact is published for noncommercial research and education. It contains
selected and reformatted text from LoCoMo by Adyasha Maharana, Dong-Ho Lee,
Sergey Tulyakov, Mohit Bansal, Francesco Barbieri and Yuwei Fang (2024),
"Evaluating Very Long-Term Conversational Memory of LLM Agents".

- Fixed upstream release: https://github.com/snap-research/locomo/tree/3eb6f2c585f5e1699204e3c3bdf7adc5c28cb376
- Original dataset: https://github.com/snap-research/locomo/blob/3eb6f2c585f5e1699204e3c3bdf7adc5c28cb376/data/locomo10.json
- Upstream license: https://github.com/snap-research/locomo/blob/3eb6f2c585f5e1699204e3c3bdf7adc5c28cb376/LICENSE.txt
- License: Creative Commons Attribution-NonCommercial 4.0 International,
  https://creativecommons.org/licenses/by-nc/4.0/ ; full text in LICENSE_LOCOMO.txt.
- Paper: https://aclanthology.org/2024.acl-long.747/

Changes: 20 released questions were selected using seed 20261014. Dialogue text
was selected, XML-escaped and arranged in three history-context conditions.
The prompts add project instructions. responses.jsonl contains project-generated
model answers, not reference annotations; these answers can be factually wrong.
The archive adds experimental protocol, runtime metadata and lexical proxy scores.
It contains no images and no records from real CBT users or patients.

LoCoMo-derived content retains CC BY-NC 4.0 terms. This audit selection and its
project additions are supplied for noncommercial research under CC BY-NC 4.0
where the project can license them; no additional rights over underlying material
are claimed. Retain the creator credits, license and change notices when sharing.
No endorsement by the original creators is implied. The license's warranty and
liability disclaimers apply. This is not clinical validation.

The original bytes of the archived protocol, prompts, references and responses
are preserved. The historical v1 protocol did not preapprove the reported model
alias. Recomputing these artifacts cannot retroactively validate model identity,
prove semantic correctness, or prove that an external provider used particular
model weights. Hashes establish integrity against the recorded audit manifest.
